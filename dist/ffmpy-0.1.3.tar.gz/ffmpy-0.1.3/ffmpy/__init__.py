import torch
from .ffmpy import VideoReader